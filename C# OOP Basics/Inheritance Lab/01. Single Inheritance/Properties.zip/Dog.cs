﻿using System;

namespace Inheritance_Lab
{
    public class Dog : Animal
    {
        public void Bark()
        {
            Console.WriteLine("barking...");
        }
    }

}

