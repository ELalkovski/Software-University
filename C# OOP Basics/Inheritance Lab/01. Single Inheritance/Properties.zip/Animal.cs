﻿using System;

namespace Inheritance_Lab
{
    public class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }

}

