﻿namespace _02BlackBoxInteger
{
    using System;

    class BlackBoxIntegerTests
    {
        static void Main(string[] args)
        {
            //TODO write your solution of Problem 2. Black Box Integer here
        }
    }
}
