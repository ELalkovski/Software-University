﻿namespace _09.Linked_List_Traversal
{
    using System;

    public class Node
    {

        public int Value { get; set; }

        public Node Next { get; set; }
    }
}
