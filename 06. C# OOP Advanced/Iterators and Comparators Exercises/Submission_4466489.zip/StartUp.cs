﻿namespace _09.Linked_List_Traversal
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
            var linkedList = new CustomLinkedList();

            var linesCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < linesCount; i++)
            {
                var input = Console.ReadLine().Split(' ');

                if (input[0].Equals("Add"))
                {
                    linkedList.Add(int.Parse(input[1]));
                }
                else
                {
                    linkedList.Remove(int.Parse(input[1]));
                }
            }

            Console.WriteLine(linkedList.Count);

            foreach (var item in linkedList)
            {
                Console.Write(item.Value + " ");
            }
            Console.WriteLine();
        }
    }
}
