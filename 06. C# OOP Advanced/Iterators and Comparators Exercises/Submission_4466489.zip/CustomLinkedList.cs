﻿namespace _09.Linked_List_Traversal
{
    using System.Collections;
    using System.Collections.Generic;

    public class CustomLinkedList : IEnumerable<Node>
    {
        private Node head;
        private Node tail;
        private int size;

        public CustomLinkedList()
        {
            this.head = null;
            this.tail = null;
            this.size = 0;
        }

        public int Count
        {
            get { return this.size; }
        }

        public void Add(int value)
        {
            this.size++;

            var node = new Node()
            {
                Value = value,
                Next = null           
            };

            if (this.head == null)
            {
                this.tail = node;
                this.head = this.tail;
                
            }
            else
            {
                this.tail.Next = node;
                this.tail = node;
            }
        }

        public void Remove(int value)
        {
            var currentNode = this.head;

            while (currentNode.Next != null)
            {
                if (this.head.Value == value)
                {
                    this.head = currentNode.Next;
                    this.size--;
                    break;
                }
                else if (currentNode.Next.Value == value)
                {
                    currentNode.Next = currentNode.Next.Next;
                    this.size--;
                    break;
                }
                else
                {
                    currentNode = currentNode.Next;
                }
            }
        }

        public IEnumerator<Node> GetEnumerator()
        {
            var currentNode = this.head;

            while (currentNode != null)
            {
                yield return currentNode;

                currentNode = currentNode.Next;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
