﻿namespace _07.Equality_Logic
{
    using System.Collections.Generic;

    public class PersonEqualityComparer : IEqualityComparer<Person>
    {
        public bool Equals(Person x, Person y)
        {
            return x.Name.CompareTo(y.Name) == 0 &&
                   x.Age.CompareTo(y.Age) == 0;
        }

        public int GetHashCode(Person obj)
        {
            return obj.Name.GetHashCode();
        }
    }
}
