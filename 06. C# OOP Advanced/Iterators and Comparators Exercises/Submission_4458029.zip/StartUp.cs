﻿namespace _07.Equality_Logic
{
    using System;
    using System.Collections.Generic;

    public class StartUp
    {
        public static void Main()
        {
            var linesCount = int.Parse(Console.ReadLine());

            var setOfPeople = new HashSet<Person>(new PersonEqualityComparer());
            var sortedSetOfPeople = new SortedSet<Person>();

            for (int i = 0; i < linesCount; i++)
            {
                var personInfo = Console.ReadLine().Split(' ');
                var person = new Person(personInfo[0], int.Parse(personInfo[1]));
                setOfPeople.Add(person);
                sortedSetOfPeople.Add(person);
            }

            Console.WriteLine(setOfPeople.Count);
            Console.WriteLine(sortedSetOfPeople.Count);
        }
    }
}
