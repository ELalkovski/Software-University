﻿namespace _02.Collection
{
    public interface IListyIterator
    {
        bool Move();

        bool HasNext();
        
        void Print();
    }
}
