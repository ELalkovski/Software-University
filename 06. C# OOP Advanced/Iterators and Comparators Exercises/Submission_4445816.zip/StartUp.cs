﻿namespace _02.Collection
{
    using System;
    using System.Linq;

    public class StartUp
    {
        public static void Main()
        {
            var createCommand = Console.ReadLine();

            var collection = createCommand
                .Split(' ')
                .ToList();

            collection.RemoveAt(0);

            var listyIterator = new ListyIterator<string>(collection);

            var command = Console.ReadLine();

            while (command != "END")
            {
                switch (command)
                {
                    case "Move":
                        Console.WriteLine(listyIterator.Move());
                        break;
                    case "HasNext":
                        Console.WriteLine(listyIterator.HasNext());
                        break;
                    case "Print":
                        try
                        {
                            listyIterator.Print();
                        }
                        catch (ArgumentException ae)
                        {
                            Console.WriteLine(ae.Message);
                        }
                        break;
                    case "PrintAll":
                        PrintAll(listyIterator);
                        break;
                }

                command = Console.ReadLine();
            }
        }

        private static void PrintAll(ListyIterator<string> listyIterator)
        {
            foreach (var element in listyIterator)
            {
                Console.Write(element + " ");
            }
            Console.WriteLine();
        }
    }
}
