﻿namespace _02.Collection
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class ListyIterator<T> : IListyIterator, IEnumerable<T>
    {
        private static int currentIndex = 0;

        private List<T> elements;

        public ListyIterator(List<T> elements)
        {
            this.Create(elements);
        }

        public void Create(List<T> collection)
        {
            try
            {
                this.elements = new List<T>();
                this.elements = collection;
            }
            catch (ArgumentException)
            {
            }
        }

        public bool Move() => ++currentIndex < this.elements.Count;

        public bool HasNext() => currentIndex + 1 < this.elements.Count;

        public void Print()
        {
            try
            {
                Console.WriteLine(this.elements[currentIndex]);
            }
            catch (ArgumentException e)
            {
                throw new ArgumentException("Invalid Operation!");
            }
            
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 0; i < this.elements.Count; i++)
            {
                yield return elements[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
