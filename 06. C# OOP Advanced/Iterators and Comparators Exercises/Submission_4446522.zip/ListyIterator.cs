﻿namespace _01.ListyIterator
{
    using System;
    using System.Collections.Generic;

    public class ListyIterator<T> : IListyIterator
    {
        private static int currentIndex = 0;

        private List<T> elements;

        public ListyIterator(List<T> elements)
        {
            this.Create(elements);
        }

        public void Create(List<T> collection)
        {
            this.elements = new List<T>();

            if (collection != null)
            {
                this.elements = collection;
            }
            
        }

        public bool Move()
        {
            if (currentIndex + 1 >= this.elements.Count)
            {
                return false;
            }

            currentIndex++;
            return true;
        }

        public bool HasNext() => currentIndex + 1 < this.elements.Count;

        public void Print()
        {
            try
            {
                Console.WriteLine(this.elements[currentIndex]);
            }
            catch (ArgumentException)
            {
                throw new ArgumentException("Invalid Operation!");
            }
            
        }
    }
}
