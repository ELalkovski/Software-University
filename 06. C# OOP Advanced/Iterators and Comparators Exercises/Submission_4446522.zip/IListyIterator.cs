﻿namespace _01.ListyIterator
{
    public interface IListyIterator
    {
        bool Move();

        bool HasNext();
        
        void Print();
    }
}
