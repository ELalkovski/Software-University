﻿namespace _06.Strategy_Pattern
{
    using System.Collections.Generic;

    public class NameComparator : IComparer<Person>
    {
        public int Compare(Person x, Person y)
        {
            var firstName = x.Name;
            var secondName = y.Name;

            var result = firstName.Length.CompareTo(secondName.Length);

            if (result == 0)
            {
                var firstLetter = char.ToLower(firstName[0]);
                var secondLetter = char.ToLower(secondName[0]);

                result = firstLetter.CompareTo(secondLetter);
            }

            return result;
        }
    }
}
