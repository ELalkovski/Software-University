﻿namespace _06.Strategy_Pattern
{
    using System;
    using System.Collections.Generic;

    public class StartUp
    {
        public static void Main()
        {
            SortedSet<Person> sortedByName = new SortedSet<Person>(new NameComparator());
            SortedSet<Person> sortedByAge = new SortedSet<Person>(new AgeComparator());

            var linesCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < linesCount; i++)
            {
                var personInfo = Console.ReadLine()
                    .Split(' ');

                var person = new Person(personInfo[0], int.Parse(personInfo[1]));

                sortedByName.Add(person);
                sortedByAge.Add(person);
            }

            foreach (var person in sortedByName)
            {
                Console.WriteLine(person.ToString());
            }
            foreach (var person in sortedByAge)
            {
                Console.WriteLine(person.ToString());   
            }
        }
    }
}
