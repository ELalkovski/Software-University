﻿namespace _05.Comparing_Objects
{
    public interface IPerson
    {
        string Name { get; }

        int Age { get; }

        string Town { get; }
    }
}
