﻿namespace _05.Comparing_Objects
{
    using System;
    public class Person : IPerson, IComparable<Person>
    {
        private string name;
        private int age;
        private string town;

        public Person(string name, int age, string town)
        {
            this.Name = name;
            this.Age = age;
            this.Town = town;
        }

        public string Name
        {
            get { return name; }

            private set { this.name = value; }
        }

        public int Age
        {
            get { return age; }

            private set { this.age = value; }
        }

        public string Town
        {
            get { return town; }

            private set { this.town = value; }
        }

        public int CompareTo(Person other)
        {
            var nameComparer = this.Name.CompareTo(other.Name);
            var ageComparer = this.Age.CompareTo(other.Age);
            var townComparer = this.Town.CompareTo(other.Town);

            if (nameComparer != 0)
            {
                return nameComparer;
            }
            else if (ageComparer != 0)
            {
                return ageComparer;
            }

            return townComparer;
        }
    }
}
