﻿namespace _05.Comparing_Objects
{
    using System;
    using System.Collections.Generic;

    public class StartUp
    {
        public static void Main()
        {
            var input = Console.ReadLine();
            var people = new List<Person>();

            while (input != "END")
            {
                var personInfo = input
                    .Split(' ');

                var person = new Person(personInfo[0], int.Parse(personInfo[1]), personInfo[2]);
                people.Add(person);

                input = Console.ReadLine();
            }

            var comparePersonIndex = int.Parse(Console.ReadLine()) - 1;
            var comparablePerson = people[comparePersonIndex];

            var identicalPeopleCount = 1;
            var indexCounter = 0;

            foreach (var person in people)
            {
                if (comparePersonIndex == indexCounter)
                {
                    indexCounter++;
                    continue;
                }
                if (comparablePerson.CompareTo(person) == 0)
                {
                    identicalPeopleCount++;
                }

                indexCounter++;
            }

            PrintResult(identicalPeopleCount, people.Count);
        }

        private static void PrintResult(int identicalPeopleCount, int peopleCount)
        {
            if (identicalPeopleCount == 1)
            {
                Console.WriteLine("No matches");
            }
            else
            {
                Console.WriteLine($"{identicalPeopleCount} {peopleCount - identicalPeopleCount} {peopleCount}");
            }
        }
    }
}
