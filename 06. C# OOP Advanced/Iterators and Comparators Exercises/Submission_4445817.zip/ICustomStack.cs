﻿namespace _03.Stack
{
    public interface ICustomStack<T>
    {
        void Push(T element);

        void Pop();

        int Count();
    }
}
