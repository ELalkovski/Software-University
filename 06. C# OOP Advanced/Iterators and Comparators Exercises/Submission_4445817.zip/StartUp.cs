﻿namespace _03.Stack
{
    using System;
    using System.Linq;

    public class StartUp
    {
        public static void Main()
        {
            var customStack = new CustomStack<string>();

            var input = Console.ReadLine();

            while (input != "END")
            {
                var tokens = input
                    .Split(new []{',', ' '}, StringSplitOptions.RemoveEmptyEntries)
                    .ToList();

                switch (tokens[0])
                {
                    case "Push":
                        tokens.RemoveAt(0);

                        foreach (var element in tokens)
                        {
                            customStack.Push(element);
                        }
                        break;
                    case "Pop":
                        customStack.Pop();
                        break;
                }

                input = Console.ReadLine();
            }

            Print(customStack);
        }

        private static void Print(CustomStack<string> customStack)
        {
            for (int i = 0; i < 2; i++)
            {
                foreach (var element in customStack)
                {
                    Console.WriteLine(element);
                }
            }
        }
    }
}
