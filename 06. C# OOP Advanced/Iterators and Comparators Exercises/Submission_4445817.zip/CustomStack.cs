﻿namespace _03.Stack
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class CustomStack<T> : ICustomStack<T>, IEnumerable<T>
    {
        private static int currentIndex = -1;

        private List<T> collection;

        public CustomStack()
        {
            this.collection = new List<T>();
        }

        public void Push(T element)
        {
            this.collection.Add(element);
            currentIndex++;
        }

        public void Pop()
        {
            if (this.collection.Count > 0)
            {
                this.collection.RemoveAt(currentIndex);

                if (--currentIndex < 0)
                {
                    currentIndex = 0;
                }
            }
            else
            {
                Console.WriteLine("No elements");
            }
        }

        public int Count()
        {
            return this.collection.Count;
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = this.collection.Count - 1; i >= 0; i--)
            {
                yield return this.collection[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
