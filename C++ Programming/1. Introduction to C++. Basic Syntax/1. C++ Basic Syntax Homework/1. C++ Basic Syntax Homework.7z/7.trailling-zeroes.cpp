#include <iostream>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int zeroesCount(0);

    for (int i=5; n/i>=1; i *= 5)
    {
        zeroesCount += n/i;
    }

    cout <<"Trailing zeroes count is: " << zeroesCount << endl;

}
