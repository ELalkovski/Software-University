#include <iostream>
using namespace std;

int fib(int number)
{
   if (number <= 1)
   {
      return number;
   }

   return fib(number-1) + fib(number-2);
}

int main()
{
    int number;
    cin >> number;
    cout << "The " << number << "th Fibonacci number is: " << fib(number) << endl;
}
