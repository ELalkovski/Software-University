# include <iostream>
using namespace std;

int main()
{
    int n;
    int maxNum(0), minNum;
    int currNum;
    cin >> n;


    for(int i = 0; i < n; i++)
    {
        cin >> currNum;

        if(currNum > maxNum)
        {
            maxNum = currNum;
        }
        else if(currNum < minNum)
        {
            minNum = currNum;
        }
    }

    cout << "Minimal number is: " << minNum << endl;
    cout << "Maximal number is: " << maxNum << endl;
}
