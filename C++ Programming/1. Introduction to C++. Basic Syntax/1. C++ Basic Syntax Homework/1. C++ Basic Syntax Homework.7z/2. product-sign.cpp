#include<iostream>
using namespace std;

int main()
{
    double firstNum, secondNum, thirdNum;
    cin >> firstNum >> secondNum >> thirdNum;

    bool firstSing = firstNum > 0;
    bool secondSing = secondNum > 0;
    bool thirdSing = thirdNum > 0;

    if(firstSing && secondSing && thirdSing)
    {
        cout << "+" << endl;
    }
    else
    {
        cout << "-" << endl;
    }

    return 0;
}
