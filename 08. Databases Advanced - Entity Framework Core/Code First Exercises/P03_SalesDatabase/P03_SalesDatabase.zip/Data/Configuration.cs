﻿namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-UBA0UC1\SQLEXPRESS;Database=Sales;Integrated Security=True;";
    }
}
