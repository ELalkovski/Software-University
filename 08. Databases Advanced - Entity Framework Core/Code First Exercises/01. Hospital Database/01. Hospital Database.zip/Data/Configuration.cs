﻿namespace P01_HospitalDatabase.Data 
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-UBA0UC1\SQLEXPRESS;Database=Hospital;Integrated Security=True;";
    }
}
