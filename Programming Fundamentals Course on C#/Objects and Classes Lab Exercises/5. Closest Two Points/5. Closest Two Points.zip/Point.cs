﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _5.Closest_Two_Points
{
    public class Point
    {
        public double X { get; set; }
        public double Y { get; set; }
    }
}
