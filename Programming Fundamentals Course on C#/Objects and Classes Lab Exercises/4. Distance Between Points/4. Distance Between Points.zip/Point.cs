﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _4.Distance_Between_Points
{
    public class Point
    {
        public double x { get; set; }
        public double y { get; set; }
    }
}
