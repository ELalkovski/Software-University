﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _8.Mentor_group
{
    public class Student
    {
        public string Name { get; set; }

        public List<DateTime> Attendings { get; set; }

        public List<string> Comments { get; set; }
    }
}
