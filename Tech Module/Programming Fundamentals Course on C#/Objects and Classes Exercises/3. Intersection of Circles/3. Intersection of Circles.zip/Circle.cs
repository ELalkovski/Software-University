﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace _3.Intersection_of_Circles
{
    public class Circle
    {
        public Point Center { get; set; }
        public int Radius { get; set; }
        
    }
}
