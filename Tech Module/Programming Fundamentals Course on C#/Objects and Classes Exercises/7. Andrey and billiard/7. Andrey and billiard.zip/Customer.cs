﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _7.Andrey_and_billiard
{
    public class Customer
    {
        public string Name { get; set; }

        public Dictionary<string, int> ProductsBought { get; set; }

        public double Bill { get; set; }
    }
}
