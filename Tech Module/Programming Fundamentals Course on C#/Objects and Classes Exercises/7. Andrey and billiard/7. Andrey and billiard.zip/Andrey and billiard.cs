﻿namespace _7.Andrey_and_billiard
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    class AndreyAndBilliard
    {

        public static void Main()
        {
            var entityAmount = int.Parse(Console.ReadLine());
            var shopList = new Dictionary<string, double>();

            for (int i = 0; i < entityAmount; i++)
            {
                var input = Console.ReadLine()
                    .Split('-');
                var productKind = input[0];
                var productPrice = double.Parse(input[1]);

                if (!shopList.ContainsKey(productKind))
                {
                    shopList.Add(productKind, productPrice);
                }
                else
                {
                    shopList[productKind] = productPrice;
                }


            }



            var customersList = new List<Customer>();
            var inputCustomer = Console.ReadLine().Split('-', ',');

            while (inputCustomer[0] != "end of clients")
            {
                var eachCustomer = new Customer();
                eachCustomer.ProductsBought = new Dictionary<string, int>();
                var name = inputCustomer[0];
                var typeOfProduct = inputCustomer[1];
                var quantityOfProduct = int.Parse(inputCustomer[2]);

                if (shopList.ContainsKey(typeOfProduct))
                {
                    eachCustomer.Name = name;
                    eachCustomer.ProductsBought.Add(typeOfProduct, quantityOfProduct);
                    eachCustomer.Bill = shopList[typeOfProduct] * quantityOfProduct;
                    customersList.Add(eachCustomer);
                }
                inputCustomer = Console.ReadLine().Split('-', ',');
            }

            var orderedCustomersList = customersList
                .OrderBy(x => x.Name)
                .ThenBy(x => x.Bill)
                .ToList();

            double sum = 0;

            foreach (var customer in orderedCustomersList)
            {
                Console.WriteLine(customer.Name);

                foreach (KeyValuePair<string, int> item in customer.ProductsBought)
                {
                    Console.WriteLine("-- {0} - {1}", item.Key, item.Value);
                }

                Console.WriteLine("Bill: {0:f2}", customer.Bill);
                sum += customer.Bill;
            }
            Console.WriteLine("Total bill: {0:f2}", sum);
        }
    }
}
